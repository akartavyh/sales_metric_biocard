@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0start-dashboard.ps1"
pause
